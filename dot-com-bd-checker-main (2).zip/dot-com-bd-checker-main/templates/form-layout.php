<div class="bdc-wrapper">
    <h2 class="bdc-title">BD Domain Availability Checker</h2>

    <div class="bdc-form">
        <input type="text" id="bd-domain-input" placeholder="Enter domain name (without extension)">
        <button id="bd-domain-submit">Search</button>
    </div>

    <div id="bd-domain-result"></div>
</div>
